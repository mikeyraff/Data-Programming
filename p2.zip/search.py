class Node():
    def __init__(self, key):
        self.key = key
        self.values = []
        self.left = None
        self.right = None
    def __len__(self):
        size = len(self.values)
        if self.left != None:
            size += len(self.left)
        if self.right != None:
            size += len(self.right)
        return size
    def lookup(self, key):
        if key == self.key:
            return self.values
        if key < self.key and self.left != None:
            return self.left.lookup(key)
        if key > self.key and self.right != None:
            return self.right.lookup(key)
        else:
            return []

class BST():
    def __init__(self):
        self.root = None

    def add(self, key, val):
        if self.root == None:
            self.root = Node(key)
        curr = self.root
        while True:
            if key < curr.key:
                if curr.left == None:
                    curr.left = Node(key)
                curr = curr.left
            elif key > curr.key:
                if curr.right == None:
                    curr.right = Node(key)
                curr = curr.right
            else:
                assert curr.key == key
                break
        curr.values.append(val)
        
    def __dump(self, node):
        if node == None:
            return
        self.__dump(node.right)           
        print(node.key, ":", node.values)  
        self.__dump(node.left)             

    def dump(self):
        self.__dump(self.root)
    
    def __getitem__(self, key):
        return self.root.lookup(key)
    
    def height(self):
        return self.__height(self.root)

    def __height(self, node):
        if node is None:
            return 0
        else:
            left_height = self.__height(node.left)
            right_height = self.__height(node.right)
            return max(left_height, right_height) + 1
        
    def count_leaf_nodes(self):
        def _count_leaf_nodes(node):
            if node is None:
                return 0
            elif node.left is None and node.right is None:
                return 1
            else:
                return _count_leaf_nodes(node.left) + _count_leaf_nodes(node.right)
        
        return _count_leaf_nodes(self.root)
    
    def third_largest_interest_rate(bst):
        nodes = []
        stack = []
        curr = bst.root
        while True:
            if curr is not None:
                stack.append(curr)
                curr = curr.left
            elif stack:
                curr = stack.pop()
                nodes.append(curr)
                curr = curr.right
            else:
                break
        if len(nodes) < 3:
            return None
        return nodes[-3].key

