import json
import zipfile
import csv
from io import TextIOWrapper

class Applicant:
    def __init__(self, age, race):
        race_lookup = {
    "1": "American Indian or Alaska Native",
    "2": "Asian",
    "21": "Asian Indian",
    "22": "Chinese",
    "23": "Filipino",
    "24": "Japanese",
    "25": "Korean",
    "26": "Vietnamese",
    "27": "Other Asian",
    "3": "Black or African American",
    "4": "Native Hawaiian or Other Pacific Islander",
    "41": "Native Hawaiian",
    "42": "Guamanian or Chamorro",
    "43": "Samoan",
    "44": "Other Pacific Islander",
    "5": "White",
}
        self.age = age
        self.race = set()
        for r in race:
            if r in race_lookup:
                self.race.add(race_lookup[r])

    def __repr__(self):
        races = sorted(self.race)
        return f"Applicant({repr(self.age)}, {repr(races)})"

    def lower_age(self):
        return int(self.age.replace('<', '').replace('>', '').split('-')[0])

    def __lt__(self, other):
        return self.lower_age() < other.lower_age()
    
class Loan(Applicant):
    def __init__(self, values):
        self.loan_amount = float(values["loan_amount"]) if (values["loan_amount"] != "NA" and values["loan_amount"] != "Exempt") else -1
        self.property_value = float(values["property_value"]) if (values["property_value"] != "NA" and values["property_value"] != "Exempt") else -1
        self.interest_rate = float(values["interest_rate"]) if (values["interest_rate"] != "NA" and values["interest_rate"] != "Exempt") else -1
        self.applicants = []
        applicant_age = values["applicant_age"]
        applicant_race = [values["applicant_race-1"], values["applicant_race-2"], values["applicant_race-3"], values["applicant_race-4"], values["applicant_race-5"]]
        self.applicants.append(Applicant(applicant_age, applicant_race))
        
        if values["co-applicant_age"] != "9999":
            co_applicant_age = values["co-applicant_age"]
            co_applicant_race = applicant_race = [values["co-applicant_race-1"], values["co-applicant_race-2"], values["co-applicant_race-3"], values["co-applicant_race-4"], values["co-applicant_race-5"]]
            self.applicants.append(Applicant(co_applicant_age, co_applicant_race))
            
    def __str__(self):
        return f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"
    
    def __repr__(self):
        return f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"
    
    def yearly_amounts(self, yearly_payment):
        amt = self.loan_amount
        interest = (self.interest_rate/100)
        while amt > 0 and interest > 0:
            yield amt
            amt = amt + (interest*amt)
            amt = amt - yearly_payment

class Bank(Loan):
    def __init__(self, bank):
        self.loans = []
        f = open('banks.json')
        data = json.load(f)
        f.close()
        for i in data:
            if i['name'] == bank:
                self.lei = i['lei']
        zf = zipfile.ZipFile('wi.zip')
        f = zf.open('wi.csv')
        reader = csv.DictReader(TextIOWrapper(f))
        for file in reader:
            if self.lei == file['lei']:
                attribute = Loan(file)
                self.loans.append(Loan(file))
        f.close()
        zf.close()
        
    def __len__(self):
        return len(self.loans)
    
    def __getitem__(self, index):
        return self.loans[index]